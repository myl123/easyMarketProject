import React, { Component } from 'react'
class Categoryst extends Component {
    render() {
        return (
            <div className="wrap">
            	88
            </div>
        )
    }
}
export default  Categoryst
