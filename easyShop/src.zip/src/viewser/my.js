import React, { Component } from 'react'
import Footer from '../component/footer'
class My extends Component {
    render() {
        return (
            <div className="wrap">
            	<div className="header">我的</div>
            	<Footer/>
            </div>
        )
    }
}
export default  My
