import React, { Component } from 'react'
import {Button} from "antd"
 class Categorys extends Component {
    render() {
        return (
            <div className="categorys">
            45454
          </div>
        )
    }
}
export default Categorys
