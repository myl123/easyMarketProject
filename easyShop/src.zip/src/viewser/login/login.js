import React, { Component } from 'react'
import "./login.scss"
import {Button} from "antd"
import { inject, observer } from 'mobx-react';

@inject("login")
@observer

 class Login extends Component {
   
  state = {
    phone: "",
    pwd: ""
}
render() {
console.log(this.props.login)
return (
    <div className="loginBox">
    <div className="logo">
      <img src="http://yanxuan.nosdn.127.net/bd139d2c42205f749cd4ab78fa3d6c60.png" alt=""/>
    </div>
    <div className="loginMain">
      <div className="inputWrap onePx_bottom">
        <input type="text" defaultValue={15323807318} placeholder="请输入手机号码" onChange={(e) => this.changePhone(e)}/>
      </div>
      <div className="inputWrap onePx_bottom">
        <input type="password" defaultValue={123456} placeholder="请输入登录密码" onChange={(e) => this.changePass(e)}/>
      </div>
      <div className="loginBtn">
        <Button type="primary" onClick={this.submit} className="btn">登录</Button>
      </div>
    </div>
  </div>
)
}
changePhone = (e) => {
this.setState({
  phone: e.target.value
})
}
changePass = (e) => {
this.setState({
  pwd: e.target.value
})
}

submit = () => {
let { phone, pwd } = this.state;
this.props.login.getLogin(phone, pwd);
if (this.props.login.loginUser === 0) {
  this.props.history.push('/home/index');
} else if (this.props.login.loginUser === 1000) {
  alert('phone或password错误！');
}
this.setState({
  phone: '',
  pwd: ''
})
}
}
export default Login
