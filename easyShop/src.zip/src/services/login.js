import request from '../utils/request';

//获取首页数据
export function loginData(params){
    console.log(params)
//   return request({
//       url:'/auth/loginByMobile',
//       method:"post"
//   })
}
