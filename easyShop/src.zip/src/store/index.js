// 引入模块
import Home from './modules/home'
import Fication from './modules/fication'
// 实例化模块
const home = new Home();
const fication=new Fication()
export default{
    home,
	fication
}
