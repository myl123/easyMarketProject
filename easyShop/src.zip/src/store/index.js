// 引入模块
import Home from './modules/homeM'

// 实例化模块
const home = new Home();

export default{
    home
}