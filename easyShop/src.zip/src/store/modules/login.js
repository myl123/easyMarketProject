import { observable, action } from "mobx";

export default class Login{
    // @action 修饰方法
    @observable logindata=[] 

    @action async getLogin(phone, pwd) {
        console.log(pwd,phone)
        // window.localStorage.setItem('user',phone)
        // let data = await login({ mobile: phone, password: pwd })
        // if (data.errno === 0) {
        //     setCookie(data.data.sessionKey)
        //     this.logindata = data.errno;

        // } else {
        //     this.logindata = 1000;
        // }
    }

}