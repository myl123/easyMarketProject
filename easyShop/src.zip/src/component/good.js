import React, { Component } from 'react'
class Good extends Component {
    render() {
        return (
           <div className="goodsAttribute">
           ———— 商品参数 ————
           </div>
        )
    }
}
export default Good